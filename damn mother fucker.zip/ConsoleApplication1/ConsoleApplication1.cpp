﻿#include <SFML/Graphics.hpp>
#include <cmath>
#include <cstring>

const float deg_to_rad = 0.01745329f;

enum tank_type {
    protected_tank,
    attack_tank,
    speed_tank
};

enum player {
    player1,
    player2,
    both
};

enum GameState {
    StartScreen,
    Settings,
    InGame
};

class Weapon {
public:
    int damage;
    int reload;

    Weapon(int d, int r) : damage(d), reload(r) {}
};

class Tank {
protected:
    int health;
    int base_damege;
    int shield;
    sf::Sprite sprite;
    sf::Texture texture;
    float speed;
    float rotationSpeed;
    float angle;
    Weapon* weapon;
    player player_type;

public:
    Tank() {}
    Tank(int h, int d, int s, float sp, float rs, player pt, const std::string& texturePath, Weapon* w) {
        health = h;
        base_damege = d;
        shield = s;
        speed = sp;
        rotationSpeed = rs;
        player_type = pt;
        texture.loadFromFile(texturePath);
        sprite.setTexture(texture);
        sprite.setOrigin(32, 64);
        if (player_type == player1) {
            sprite.setPosition(300.0f, 720.0f);
            angle = 0.0;
        }
        else if (player_type == player2) {
            sprite.setPosition(2260.0f, 720.0f);
            angle = 180.0;
        }
        sprite.setRotation(angle + 90);
        weapon = w;
    }

    void set_weapon(Weapon* w) {
        weapon = w;
    }

    Weapon* show_weapon() {
        return weapon;
    }

    void moveUp() {
        float delta_x = speed * cos(angle * deg_to_rad);
        float delta_y = speed * sin(angle * deg_to_rad);
        sf::Vector2f newPosition = sprite.getPosition() + sf::Vector2f(delta_x, delta_y);
        if (newPosition.x >= 100 && newPosition.x <= 2460 - sprite.getTextureRect().width && newPosition.y >= 100 && newPosition.y <= 1340 - sprite.getTextureRect().height) {
            sprite.move(delta_x, delta_y);
        }
    }

    void moveDown() {
        float delta_x = speed * cos(angle * deg_to_rad);
        float delta_y = speed * sin(angle * deg_to_rad);
        sf::Vector2f newPosition = sprite.getPosition() - sf::Vector2f(delta_x, delta_y);
        if (newPosition.x >= 100 && newPosition.x <= 2460 - sprite.getTextureRect().width && newPosition.y >= 100 && newPosition.y <= 1340 - sprite.getTextureRect().height) {
            sprite.move(-delta_x, -delta_y);
        }
    }

    void moveLeft() {
        angle -= rotationSpeed;
        sprite.setRotation(angle + 90);
    }

    void moveRight() {
        angle += rotationSpeed;
        sprite.setRotation(angle + 90);
    }

    sf::Sprite getSprite() {
        return sprite;
    }

    bool die() {
        if (health > 0) return false;
        else return true;
    }

    void injure(int damage) {
        int actual_damage = damage - this->shield;
        if (actual_damage > 0)
            this->health -= actual_damage;
    }
};

class Protected_tank : public Tank {
public:
    Protected_tank() : Tank() {}
    Protected_tank(player player_type, const std::string& texturePath, Weapon* w) : Tank(150, 20, 80, 3.0f, 1.0f, player_type, texturePath, w) {}
};

class Attack_tank : public Tank {
public:
    Attack_tank() : Tank() {}
    Attack_tank(player player_type, const std::string& texturePath, Weapon* w) : Tank(100, 40, 50, 3.0f, 1.0f, player_type, texturePath, w) {}
};

class Speed_tank : public Tank {
public:
    Speed_tank() : Tank() {}
    Speed_tank(player player_type, const std::string& texturePath, Weapon* w) : Tank(100, 20, 50, 4.0f, 1.5f, player_type, texturePath, w) {}
};

class Player {
public:
    Tank* tankPtr;
    Player() {}
    Player(player player_type, tank_type type, const std::string& texturePath, Weapon* w) {
        if (type == protected_tank) {
            tankPtr = new Protected_tank(player_type, texturePath, w);
        }
        else if (type == attack_tank) {
            tankPtr = new Attack_tank(player_type, texturePath, w);
        }
        else if (type == speed_tank) {
            tankPtr = new Speed_tank(player_type, texturePath, w);
        }
    }

    ~Player() {
        delete tankPtr;
    }

    bool die() {
        return this->tankPtr->die();
    }
};

int main() {
    int width = 2560, height = 1440;
    sf::RenderWindow window(sf::VideoMode(width, height), "Tank Game", sf::Style::Fullscreen);
    bool setup = false;
    Player* player_1, * player_2;
    Weapon* weapon_1, * weapon_2;
    player_1 = new Player;
    player_2 = new Player;

    sf::Texture startTexture;
    startTexture.loadFromFile("start.png");

    sf::Sprite startSprite(startTexture);


    GameState gameState = GameState::StartScreen;  // 使用枚举类型表示游戏状态，初始为StartScreen

    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed) {
                delete player_1;
                delete player_2;
                window.close();
            }
            if (event.type == sf::Event::KeyPressed) {
                if (gameState == GameState::StartScreen) {  // 在初始界面时的按键处理
                    if (event.key.code == sf::Keyboard::Space) {
                        gameState = GameState::InGame;  // 按下空格，进入游戏状态
                    }
                }
            }
        }

        window.clear(sf::Color::White);

        if (gameState == GameState::StartScreen) {  // 根据游戏状态进行绘制
            window.draw(startSprite);
        }
        else if (gameState == GameState::InGame) {  // 进入游戏后的逻辑
            if (setup == false) {
                delete player_1;
                delete player_2;
                weapon_1 = new Weapon(50, 3);
                weapon_2 = new Weapon(40, 4);
                player_1 = new Player(player::player1, tank_type::protected_tank, "green_tank.png", weapon_1);
                player_2 = new Player(player::player2, tank_type::speed_tank, "red_tank.png", weapon_2);
                setup = true;
            }
            else {
                if (sf::Keyboard::isKeyPressed(sf::Keyboard::W))
                    player_1->tankPtr->moveUp();
                else if (sf::Keyboard::isKeyPressed(sf::Keyboard::S))
                    player_1->tankPtr->moveDown();
                else if (sf::Keyboard::isKeyPressed(sf::Keyboard::A))
                    player_1->tankPtr->moveLeft();
                else if (sf::Keyboard::isKeyPressed(sf::Keyboard::D))
                    player_1->tankPtr->moveRight();

                if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up))
                    player_2->tankPtr->moveUp();
                else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down))
                    player_2->tankPtr->moveDown();
                else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left))
                    player_2->tankPtr->moveLeft();
                else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right))
                    player_2->tankPtr->moveRight();

                window.draw(player_1->tankPtr->getSprite());
                window.draw(player_2->tankPtr->getSprite());
            }
            
            
        }

        window.display();
    }

    return 0;
}